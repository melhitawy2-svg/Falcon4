package com.falconvpn.app.vpn.platform

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.example.vpnstarter.MainActivity
import com.falconvpn.app.vpn.engine.SecureProfileStore
import com.falconvpn.app.vpn.engine.SingBoxConfigWriter

/**
 * Android VPN lifecycle shell. The service handles Android's foreground-service
 * and notification requirements, but deliberately fails closed until the libbox
 * BoxService/PlatformInterface adapter is compiled and wired in.
 */
class FalconVpnService : VpnService() {
    private val store by lazy { SecureProfileStore(applicationContext) }
    private val configWriter by lazy { SingBoxConfigWriter(applicationContext) }
    private var foregroundStarted = false
    private val timerHandler = Handler(Looper.getMainLooper())
    private var sessionEndsAtMillis = 0L
    private val sessionTimer = object : Runnable {
        override fun run() {
            val remaining = sessionEndsAtMillis - System.currentTimeMillis()
            if (sessionEndsAtMillis <= 0L) return
            if (remaining <= 0L) {
                stopRealSession("انتهت مدة الجلسة المجانية (15 دقيقة).")
            } else {
                getSharedPreferences(STATUS_PREFS, MODE_PRIVATE).edit()
                    .putLong(KEY_REMAINING_SECONDS, (remaining + 999L) / 1000L).apply()
                timerHandler.postDelayed(this, 1000L)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                configWriter.delete()
                updateState(STATE_DISCONNECTED, "تم إيقاف الاتصال.")
                stopForegroundCompat()
                stopSelf(startId)
                return START_NOT_STICKY
            }
            ACTION_START -> startConnection(startId)
            ACTION_ADD_BONUS_TIME -> {
                if (sessionEndsAtMillis > System.currentTimeMillis()) {
                    sessionEndsAtMillis += FREE_SESSION_MILLIS
                    getSharedPreferences("falcon_ad_rewards", MODE_PRIVATE).edit().putLong("bonus_seconds", 0L).apply()
                    getSharedPreferences(STATUS_PREFS, MODE_PRIVATE).edit()
                        .putLong(KEY_SESSION_ENDS_AT, sessionEndsAtMillis)
                        .putLong(KEY_REMAINING_SECONDS, ((sessionEndsAtMillis - System.currentTimeMillis()) + 999L) / 1000L)
                        .apply()
                    timerHandler.removeCallbacks(sessionTimer)
                    timerHandler.post(sessionTimer)
                }
            }
            else -> {
                stopSelf(startId)
                return START_NOT_STICKY
            }
        }
        return START_NOT_STICKY
    }

    private fun startConnection(startId: Int) {
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, notification("جارٍ تجهيز اتصال Falcon VPN"))
        foregroundStarted = true
        updateState(STATE_CONNECTING, "جارٍ تجهيز الاتصال…")

        // Defense in depth: permission is normally requested by MainActivity, but the
        // service must also fail safely if it is started from a notification/system path.
        if (VpnService.prepare(this) != null) {
            failAndStop(startId, "إذن VPN غير متاح. افتح التطبيق واضغط اتصال لمنح الإذن.", STATE_NEEDS_PERMISSION)
            return
        }

        // Do not establish an empty TUN or show CONNECTED without a live engine.
        val profile = runCatching { store.getSelectedForEngine() }.getOrNull()
        if (profile == null) {
            failAndStop(startId, "حدد كونفج محفوظًا أولًا.")
            return
        }

        // Prepare the real sing-box configuration in private app storage. The libbox
        // CommandServer/PlatformInterface adapter is still a separate required step;
        // do not establish a dummy TUN or report CONNECTED before that adapter exists.
        try {
            configWriter.write(profile)
        } catch (e: Exception) {
            failAndStop(startId, e.message ?: "تعذر تجهيز إعدادات محرك sing-box.")
            return
        }
        failAndStop(startId, "إعدادات sing-box جاهزة، لكن ربط libbox وفتح نفق TUN لم يكتمل بعد؛ لم يتم إنشاء اتصال VPN.")
    }

    /** Call only after libbox reports a successfully started, working tunnel. */
    private fun startSessionTimerAfterEngineConnected() {
        val rewardPrefs = getSharedPreferences("falcon_ad_rewards", MODE_PRIVATE)
        val bonusSeconds = rewardPrefs.getLong("bonus_seconds", 0L).coerceAtLeast(0L)
        val sessionMillis = FREE_SESSION_MILLIS + bonusSeconds * 1000L
        rewardPrefs.edit().putLong("bonus_seconds", 0L).apply()
        sessionEndsAtMillis = System.currentTimeMillis() + sessionMillis
        getSharedPreferences(STATUS_PREFS, MODE_PRIVATE).edit()
            .putLong(KEY_SESSION_ENDS_AT, sessionEndsAtMillis)
            .putLong(KEY_REMAINING_SECONDS, sessionMillis / 1000L)
            .apply()
        timerHandler.removeCallbacks(sessionTimer)
        timerHandler.post(sessionTimer)
    }

    private fun stopSessionTimer() {
        timerHandler.removeCallbacks(sessionTimer)
        sessionEndsAtMillis = 0L
        getSharedPreferences(STATUS_PREFS, MODE_PRIVATE).edit()
            .remove(KEY_SESSION_ENDS_AT).putLong(KEY_REMAINING_SECONDS, 0L).apply()
    }

    private fun stopRealSession(reason: String) {
        // The engine stop hook will be invoked here once libbox is wired in.
        stopSessionTimer()
        configWriter.delete()
        updateState(STATE_DISCONNECTED, reason)
        stopForegroundCompat()
        stopSelf()
    }

    private fun failAndStop(startId: Int, message: String, state: String = STATE_ERROR) {
        stopSessionTimer()
        configWriter.delete()
        updateState(state, message)
        if (foregroundStarted) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.notify(NOTIFICATION_ID, notification(message))
        }
        stopForegroundCompat()
        stopSelf(startId)
    }

    private fun notification(message: String): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, FalconVpnService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle("Falcon VPN")
            .setContentText(message.take(180))
            .setContentIntent(openApp)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setOngoing(foregroundStarted)
            .setOnlyAlertOnce(true)
            .addAction(0, "إيقاف", stop)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "اتصال Falcon VPN", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun updateState(state: String, message: String) {
        getSharedPreferences(STATUS_PREFS, MODE_PRIVATE).edit()
            .putString(KEY_STATE, state)
            .putString(KEY_MESSAGE, message)
            .putLong(KEY_UPDATED_AT, System.currentTimeMillis())
            .apply()
    }

    @Suppress("DEPRECATION")
    private fun stopForegroundCompat() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE)
        else stopForeground(true)
        foregroundStarted = false
    }

    override fun onRevoke() {
        stopSessionTimer()
        configWriter.delete()
        updateState(STATE_DISCONNECTED, "تم إلغاء إذن VPN من إعدادات أندرويد؛ تم إيقاف الخدمة بأمان.")
        stopForegroundCompat()
        stopSelf()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopSessionTimer()
        configWriter.delete()
        if (foregroundStarted) stopForegroundCompat()
        super.onDestroy()
    }

    override fun onBind(intent: Intent): IBinder? = super.onBind(intent)

    companion object {
        const val ACTION_START = "com.falconvpn.app.vpn.START"
        const val ACTION_ADD_BONUS_TIME = "com.falconvpn.app.vpn.ADD_BONUS_TIME"
        const val ACTION_STOP = "com.falconvpn.app.vpn.STOP"
        const val STATUS_PREFS = "falcon_vpn_runtime_status"
        const val KEY_STATE = "state"
        const val KEY_MESSAGE = "message"
        const val KEY_UPDATED_AT = "updated_at"
        const val KEY_SESSION_ENDS_AT = "session_ends_at"
        const val KEY_REMAINING_SECONDS = "remaining_seconds"
        private const val FREE_SESSION_SECONDS = 15L * 60L
        private const val FREE_SESSION_MILLIS = FREE_SESSION_SECONDS * 1000L
        const val STATE_DISCONNECTED = "DISCONNECTED"
        const val STATE_NEEDS_PERMISSION = "NEEDS_PERMISSION"
        const val STATE_CONNECTING = "CONNECTING"
        const val STATE_CONNECTED = "CONNECTED"
        const val STATE_ERROR = "ERROR"
        private const val CHANNEL_ID = "falcon_vpn_connection"
        private const val NOTIFICATION_ID = 7101
    }
}
