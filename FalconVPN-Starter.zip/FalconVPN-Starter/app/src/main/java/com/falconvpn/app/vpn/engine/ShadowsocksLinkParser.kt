package com.falconvpn.app.vpn.engine

import java.net.URLDecoder
import java.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.URI

/**
 * Parses the common SIP002 Shadowsocks share-link form:
 * ss://BASE64(method:password)@host:port#name
 *
 * This prepares a link for a real engine; it does NOT open a socket or establish a VPN.
 */
data class ShadowsocksProfile(
    val name: String,
    val host: String,
    val port: Int,
    val method: String,
    val password: String
)

object ShadowsocksLinkParser {
    fun parse(rawLink: String): ShadowsocksProfile {
        val raw = rawLink.trim()
        require(raw.startsWith("ss://", ignoreCase = true)) { "Not a Shadowsocks link" }
        val uri = URI(raw)
        val host = uri.host ?: throw IllegalArgumentException("Missing server host")
        val port = uri.port
        require(port in 1..65535) { "Invalid server port" }

        val rawUserInfo = uri.rawUserInfo ?: throw IllegalArgumentException("Missing encrypted method/password section")
        val decoded = decodeUserInfo(rawUserInfo)
        val splitAt = decoded.indexOf(':')
        require(splitAt > 0 && splitAt < decoded.lastIndex) { "Expected method:password in Shadowsocks link" }
        val method = decoded.substring(0, splitAt)
        val password = decoded.substring(splitAt + 1)
        require(method.matches(Regex("[A-Za-z0-9._-]+"))) { "Invalid encryption method" }
        require(password.isNotEmpty()) { "Missing password" }

        val label = uri.rawFragment?.let { URLDecoder.decode(it, Charsets.UTF_8.name()) }?.takeIf { it.isNotBlank() } ?: "Shadowsocks server"
        return ShadowsocksProfile(label, host, port, method, password)
    }

    /** Generates a sing-box configuration for a compatible libbox engine integration. */
    fun toSingBoxConfig(profile: ShadowsocksProfile): String {
        val outbound = JSONObject()
            .put("type", "shadowsocks")
            .put("tag", "proxy")
            .put("server", profile.host)
            .put("server_port", profile.port)
            .put("method", profile.method)
            .put("password", profile.password)
        val direct = JSONObject().put("type", "direct").put("tag", "direct")
        val dns = JSONObject()
            .put("servers", JSONArray().put(JSONObject().put("tag", "dns-remote").put("address", "1.1.1.1").put("detour", "proxy")))
        val tun = JSONObject()
            .put("type", "tun")
            .put("tag", "tun-in")
            .put("inet4_address", JSONArray().put("172.19.0.1/30"))
            .put("auto_route", true)
            .put("strict_route", false)
            .put("stack", "mixed")
        return JSONObject()
            .put("log", JSONObject().put("level", "warn"))
            .put("dns", dns)
            .put("inbounds", JSONArray().put(tun))
            .put("outbounds", JSONArray().put(outbound).put(direct))
            .put("route", JSONObject().put("final", "proxy").put("auto_detect_interface", true))
            .toString(2)
    }

    private fun decodeUserInfo(raw: String): String {
        // SIP002 permits the method/password pair to be base64-encoded as a whole.
        val candidate = raw.substringBeforeLast('@', raw)
        return try {
            val normalized = candidate.replace('-', '+').replace('_', '/')
            val padded = normalized + "=".repeat((4 - normalized.length % 4) % 4)
            String(Base64.getDecoder().decode(padded), Charsets.UTF_8)
        } catch (_: IllegalArgumentException) {
            // Some links use percent-encoded plain method:password.
            URLDecoder.decode(candidate, Charsets.UTF_8.name())
        }
    }
}
